import axios from "axios";

const instance = axios.create({
  baseURL: "https://backend-clone3.herokuapp.com/",
});

export default instance;
